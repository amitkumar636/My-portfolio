const toggle = document.getElementById(toggleId),
    nav = document.getElementById(element)